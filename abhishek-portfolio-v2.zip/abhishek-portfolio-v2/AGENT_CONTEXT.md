# Agent Context

A dated log of decisions actually made in conversation with the site owner,
including things proposed and explicitly rejected. **Read this before
touching anything listed below.** If you're about to add a performance
caveat, reframe something around recruiters, reintroduce a dropped design
element, or redo work already settled here — stop and check this file first.
It exists so a new session doesn't re-litigate a closed conversation or
quietly undo a decision the owner already made on purpose.

`DESIGN_DIRECTION.md` holds the standing philosophy. This file holds the
specific, dated calls that shaped or came out of that philosophy. Newer
entries here take precedence if the two ever seem to disagree — it means the
philosophy got refined by a real conversation.

Add a new entry every time a genuine decision is made or reversed. Keep
entries short: what was decided, and the one-line reason. Don't narrate the
whole conversation.

---

### 2026-09-15 — Rebuild from single-file prototype to modular site (v2)

Split the original single-file `bright-ledger-portfolio.html` prototype into
the current `assets/css/` + `assets/js/` structure. Full rationale is in
`PROJECT_GUIDE.md`. Not reversible without a Major-Change entry there.

### 2026-09-15 — Router initialization race (bug, fixed)

`ROUTER.init()` fired the initial panel activation before `ART.init()` had
registered its `onChange` listener, so loading the site directly on `#art`
silently skipped the Sketchfab sync. Fixed by splitting `ROUTER.init()`
(binds controls) from `ROUTER.start()` (fires the first activation), and
calling `start()` in `main.js` only after every module has registered its
listeners. If you add a new module that listens for panel changes, register
it before `ROUTER.start()` runs, not after.

### 2026-09-15 — Contrast fix: darker red/blue under text

`--red` under white text measured ~4.38:1; `--gold` on `--sky` measured
~3.6:1. Both fail WCAG AA (4.5:1). Fixed by moving text-bearing red and blue
surfaces to `--red-dark` and `--sky-dark`. This should have been correct on
the first pass — flagged here so it doesn't quietly regress back to the
lighter variants, which still exist in the palette for non-text uses (e.g.
plain background fills where nothing sits directly on top).

### 2026-09-15 — Audience is not recruiter-first

Explicitly rejected framing: "recruiters have 8 seconds, optimize for that."
The owner's position: this portfolio is for anyone wandering by, not just
recruiters, and a plain résumé is handed over separately in actual hiring
conversations anyway. **Do not** propose simplifying the interaction model,
stripping personality, or restructuring content around a fast-recruiter-scan
use case. The résumé page can stay inside the stylized system.

### 2026-09-15 — Bundle weight / performance: tested, not a live concern

Raised as a hypothetical risk (fonts, Sketchfab API, up to 60 lazy iframes,
external icon CDN) without actually throttling the network to check. The
owner tested the live build directly on low-end hardware ("potato PC") and
confirmed it performs fine. **Do not** add performance disclaimers, "tested
on slow connections" hedges, or references to 3G/throttled scenarios into
docs, copy, or future reviews unless the owner raises a specific, concrete
performance problem they're actually seeing. Treat this as closed, not as an
open risk to keep flagging.

### 2026-09-15 — Legibility pass: pixel font sizes bumped

A review found several UI labels (stat labels, chips, tool tags, contact link
labels, roster chrome) set in Press Start 2P at 7–8px, which is hard to read
at that size regardless of screen. Token changes in `tokens.css`:

- `--fs-chrome-xs`: 7px → 9px
- `--fs-chrome-sm`: 8px → 10px
- `--fs-chrome`: 10px → 12px

Also: the ≤420px breakpoint previously shrank the mobile tab bar labels to
6px to keep five tabs on one row. Replaced with icon-only tabs at that
breakpoint (`.tabbar-btn span:not(.tab-glyph) { display: none; }`) plus an
`aria-label` on each button so the accessible name survives even though the
visible text doesn't. **Do not reintroduce a sub-8px pixel-font label
anywhere** — if something doesn't fit, shorten the label, use an icon, or
resize its container. See the anti-goal in `DESIGN_DIRECTION.md`.

### 2026-09-15 — Hero dead-space fix: restored the status line

The home hero's right panel (`.hero-side`) used `justify-content:
space-between`, which stretched an empty gap between the stat grid and the
action buttons whenever the left column was taller. Fixed two ways together:
switched `.hero-side` to `justify-content: flex-start` with a consistent
`gap`, and restored a small `"STATUS: BUILDING WORLDS"` flavor line that
existed in the original single-file prototype and was dropped during the v2
rebuild. It's mood copy, not a factual claim — same category as "Make it
readable. Make it game-ready." If the gap reappears after a future content
change, prefer adding real content over reintroducing `space-between`.
