# Design Direction

This file is the **why**. `PROJECT_GUIDE.md` is the **what** — the rules,
file boundaries, and constraints an edit has to satisfy. This file is the
creative thesis those rules exist to serve. Read both before making a design
call; if a change would satisfy `PROJECT_GUIDE.md` but violate the thesis
here, it's the wrong change even if it technically passes.

`AGENT_CONTEXT.md`, alongside this file, is the dated log of specific
decisions and resolved debates. This file is the standing philosophy those
decisions were made in service of. When the two ever seem to disagree, the
dated, more-recent entry in `AGENT_CONTEXT.md` wins — it means the philosophy
below was refined by an actual conversation with the person who owns this
site.

## Who this is for

Not just recruiters. This is a public portfolio: recruiters, other artists,
collaborators, people who wandered in from a Sketchfab profile, friends,
whoever. **Do not optimize the design toward a hypothetical recruiter's
8-second scan.** That framing was explicitly rejected. If a change trades
personality or interaction depth for faster "professional" scanning, it's
optimizing for the wrong audience. A plain résumé is handed out separately in
actual hiring contexts — this site does not need to carry that weight, and
the résumé page here does not need to be de-gamified "just in case" a
recruiter opens it.

## The core thesis

**This is an actual console/JRPG menu, not a marketing page wearing game
skin.** The test for any interaction decision: does this behave like a menu,
or does it just look like one? A hover glow that does nothing is decoration.
A cursor that actually moves with arrow keys, a panel that actually swaps
state, a prompt bar that actually reflects working key bindings — that's
mechanic. When in doubt, favor the version that's mechanically real over the
version that's merely evocative.

## Tone

Playful, but earned through function, not through applied texture. The site
should read as *made by someone who builds things that run in an engine* —
clean, considered, a little wry (the Konami code, "built like a game menu,
shipped like a portfolio," the 404 that's a continue screen) — not as a theme
slapped onto a template.

## Where the boldness goes

Spend it on the menu mechanic itself: the cursor, the keyboard control, the
inventory-style inspector, the sound design. Keep everything else — spacing,
color relationships, copy voice — quiet and disciplined around that one bold
choice. If a future change adds a second loud thing (a new animation style, a
competing visual gimmick, a different interaction metaphor bolted onto the
same page), that's very likely the wrong call. One memorable mechanic,
executed well, beats several competing for attention.

## Explicit anti-goals

These have been raised and rejected. Don't re-propose them without a new,
explicit conversation:

- **No dark mode.** Bright Ledger's blue/cream/red/gold identity is the
  point; a dark variant would be a different site, not a mode of this one.
- **No sci-fi HUD treatment.** No scanlines, neon glow, holographic panels,
  or terminal styling. This is a warm console menu, not a cyberpunk terminal.
- **No recruiter-scan optimization.** See "Who this is for" above.
- **No performance disclaimers or "tested on slow connections" hedging in
  the docs or copy.** The build has been tested directly by the site owner on
  low-end hardware and performs well. Don't add caveats implying otherwise —
  see `AGENT_CONTEXT.md` for the specific entry.
- **No shrinking type past legibility to preserve a pixel-perfect aesthetic.**
  The pixel font (Press Start 2P) is chrome — labels, badges, menu buttons —
  not a constraint that overrides being readable. If a label needs 6px to fit
  on one line, the fix is to shorten the label, drop to an icon, or resize the
  container — not to ship 6px pixel type.

## Aesthetic pillars

- **Bright Ledger palette is locked**: blue roster (`--sky` / `--sky-dark`),
  cream detail surface, red banners (`--red-dark` for text-bearing ones — see
  the contrast note below), gold selection states, chunky ink borders,
  graph-paper background. Changing this palette is a major change per
  `PROJECT_GUIDE.md`, not a tweak.
- **Numbering is earned, not decorative.** The Pipeline panel numbers its
  four stages because it genuinely is a sequence. Nothing else on the site is
  numbered, because nothing else is a sequence. Before adding `01 / 02 / 03`
  anywhere, check the content is actually ordered — if it's a set, use chips
  or a grid instead.
- **Pixel font is chrome, sans is content.** Press Start 2P carries menu
  identity: nav buttons, banners, badges, key caps, section headings. Body
  copy, descriptions, and anything meant to be read at length stays in Nunito
  Sans. Never write a paragraph in the pixel face.
- **White-on-red and gold-on-blue use the darker palette variants**
  (`--red-dark`, `--sky-dark`) specifically because the lighter ones
  (`--red`, `--sky`) fail 4.5:1 contrast. This was caught and fixed once
  already — see `AGENT_CONTEXT.md`. Don't reintroduce the lighter variants
  under text.
- **Motion is a single orchestrated moment, not scattered polish.** Panel
  transitions, the cursor nudge, the modal open — each exists to show what
  changed, not to decorate. `prefers-reduced-motion` is respected everywhere.

## Definition of "done" for a visual change

A change is done when it's disciplined enough that removing it would make the
page feel incomplete, and bold enough that it wouldn't exist on a generic
portfolio template. If it could be describe as "the kind of thing every
AI-generated portfolio has" (see the anti-patterns list in
`/mnt/skills/public/frontend-design/SKILL.md` if you have access to it — warm
cream + serif + terracotta, ALL-CAPS eyebrows with no function, cards with
identical soft shadows, a `→` on every button) — it's not done, it's a
placeholder that happens to render.
