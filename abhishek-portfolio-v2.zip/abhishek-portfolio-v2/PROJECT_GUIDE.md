# Project Guide — Portfolio Gaming Site

This file is the structural and directional source of truth for the portfolio site. It is intentionally separate from `CONTENT_SOURCE.md`, which owns factual portfolio content, links, résumé text, model IDs, and approved copy.

## AI Editing Contract

Before changing the site, read `CONTENT_SOURCE.md`, `DESIGN_DIRECTION.md`, `AGENT_CONTEXT.md`, and this file.

- Treat `CONTENT_SOURCE.md` as the authority for real-world facts and approved content.
- Treat `DESIGN_DIRECTION.md` as the authority for creative intent and thesis — the *why* behind the rules below.
- Treat `AGENT_CONTEXT.md` as the dated log of specific decisions already made, including things proposed and explicitly rejected. Check it before re-proposing anything — a closed conversation should stay closed.
- Treat this file as the authority for architecture, design constraints, implementation direction, and maintenance rules.
- Do not remove, rewrite, silently correct, or replace factual content because a different version seems more convenient.
- Preserve intentional spelling differences between Abhishek Farshwan and Abhishek Farswan. Check the context before changing either spelling.
- Keep the site honest: do not add unverified job titles, skills, project claims, metrics, or personal details.
- When a requested change conflicts with any of the other three files, pause and resolve the conflict explicitly before editing.
- After every meaningful change, verify that existing content, links, model IDs, and required behavior are still present.
- After every decision that future sessions shouldn't relitigate, add a dated entry to `AGENT_CONTEXT.md` — see that file's own instructions for format.

## Major-Change Rule

If a major shift happens, update this file in the same change. A major shift includes:

- changing the visual identity, interaction model, or responsive navigation model;
- changing the stack, build approach, or file/module boundaries;
- adding or removing a page or a persistent site-wide feature;
- changing how portfolio content is sourced, synchronized, or displayed;
- changing a locked decision or turning an open direction into a decision;
- changing a performance, accessibility, or deployment constraint.

For content-only changes, update `CONTENT_SOURCE.md`. For changes that affect both facts and structure, update both files. Keep this guide short enough that future AI-assisted edits can reliably read it before making changes.

## Current Stack

**Locked:** Plain HTML/CSS/JS, no framework, no build step. Static files load fast and stay editable by hand.

The single-file prototype (`bright-ledger-portfolio.html`) has been split into the modular structure described below. That prototype is superseded; the live implementation is `index.html` plus `assets/`.

Scripts are **classic `<script defer>`-style tags with IIFE namespaces, not ES modules**, on purpose: ES modules fail under `file://`, and the site must be openable by double-clicking `index.html` with no server.

```
/
├── index.html              home, art, pipeline, about, contact (panel router)
├── resume.html             full résumé, print-optimised
├── 404.html                not-found page
├── game/secret_level/      deliberate stub (see Sitemap)
├── user.png                favicon + roster avatar (must exist at root)
└── assets/
    ├── css/
    │   ├── tokens.css      ONLY file holding raw values (colour, type, spacing, motion)
    │   ├── base.css        reset, document shell, type primitives, focus
    │   ├── layout.css      app grid, roster shell, detail panel, topbar, prompt bar
    │   ├── nav.css         profile card, menu buttons + cursor, tab bar, sound toggle
    │   ├── components.css  cards, chips, buttons, stats, bullets, timeline, forms, toast
    │   ├── panels.css      per-panel composition (hero, art, pipeline, about, contact, résumé)
    │   ├── modal.css       inventory inspector
    │   ├── responsive.css  tablet + mobile overrides (loaded last, wins without !important)
    │   └── print.css       linked media="print"
    └── js/
        ├── data.js         mirrors CONTENT_SOURCE.md — every real fact the site renders
        ├── util.js         DOM helpers, escaping, safe storage, toasts, clipboard
        ├── sfx.js          WebAudio menu blips
        ├── chrome.js       shared roster / tab bar / prompt bar for every page
        ├── router.js       panel switching, hash sync, keyboard
        ├── art.js          Sketchfab sync, filter/sort/search, lazy viewers
        ├── inspector.js    full-size model modal
        ├── contact.js      form validation + mail composition, copy buttons
        ├── easter.js       Konami unlock
        └── main.js         boot order (idempotent)
```

Rules that keep this structure honest:

- raw values live in `tokens.css` only; other CSS files reference variables;
- CSS is split by concern, JS by behaviour, never one file per component;
- page chrome (roster, tab bar, prompt bar, footer) is generated once in `chrome.js`; pages expose `#roster-slot` and `#footer-slot` and declare `data-page` and `data-root`;
- `data.js` mirrors `CONTENT_SOURCE.md`. Facts change in `CONTENT_SOURCE.md` first, then `data.js`;
- changing one concern must not require rewriting unrelated parts of the site.

`data-page` values: `home` (panel-switching menu), `resume` (menu becomes links back to `index.html#…`), `none` (standalone pages). `data-root` is the relative path back to the site root, e.g. `../../` inside `/game/secret_level/`.

## Current Sitemap

- `/` — home, art grid, pipeline, about, contact
- `/resume` — full résumé
- `/404` — not-found page
- `/game/secret_level` — deliberate stub only; do not build it out in v1

## Structural Direction

The preferred interaction model is an actual console/JRPG menu rather than a generic scrolling marketing page:

- persistent left-hand menu on desktop;
- name, avatar, navigation list, selection cursor in the menu area;
- detail panel that changes for Home, Art, Pipeline, About, and Contact;
- art uses an inventory-style selection interaction: the grid lists assets, and INSPECT loads one asset full size with its description;
- mobile uses a full-width detail view with a thumb-friendly bottom tab bar; the roster collapses to a compact profile header.

Preserve this core interaction unless this guide is deliberately updated.

## Visual Direction

The site should feel like an actual old-school console/RPG menu: warm, playful, readable, and specific to a 3D artist. Use real menu chrome rather than generic game references:

- selection cursor or active-item indicator;
- bordered panel or dialogue-box framing;
- numbered or bracketed stage markers **only where the content is genuinely a sequence** (the pipeline is; nothing else is);
- display-style heading paired with a clean body font;
- hover states that feel like a menu cursor moving over an item.

This is explicitly not sci-fi. Avoid HUD scanlines, neon glow, holographic panels, terminal styling, and decorative effects without a clear purpose.

The visual direction is the original **Bright Ledger** menu styling: blue roster, cream detail surface, red banners, gold selection states, chunky dark borders, graph-paper background, and the original compact panel/card geometry. Press Start 2P for menu chrome, Nunito Sans for body.

Two palette corrections made for accessibility, not style: white text sits on `--red-dark` rather than `--red` (4.38:1 → 6.5:1), and gold headings/numerals sit on `--sky-dark` rather than `--sky` (3.6:1 → 6.7:1). Keep white-on-red and gold-on-blue pairings on the darker variants.

Pixel-font chrome (Press Start 2P) has a floor: nothing renders smaller than `--fs-chrome-xs` (9px as of the 2026-09-15 legibility pass — see `AGENT_CONTEXT.md`). If a label doesn't fit at that size, shorten it, use an icon, or resize its container. Do not shrink type past that floor to preserve a layout.

No dark mode. Adding one would change the visual identity and needs an explicit decision here first.

## Quality Bar

- Do not make the site read as generic AI output.
- Treat desktop, tablet, and mobile as first-class layouts.
- Prevent horizontal page overflow; the desktop roster must remain compact enough to leave the detail panel usable at common laptop widths.
- Keep performance practical: prefer transform/opacity motion, avoid stacked blur/translucency, respect `prefers-reduced-motion`.
- Every visual decision must support clarity, hierarchy, identity, or interaction.
- One coherent spacing scale, type scale, and colour/border relationship across the site.
- Visible keyboard focus everywhere; colour pairings clear 4.5:1.
- Favor intentional restraint over adding effects for their own sake.

## Site-wide Features

These are persistent features; removing one is a major change.

- **Keyboard navigation.** Arrow keys move the cursor, Enter selects, `1`–`5` jump to a panel, `R` opens the résumé, `M` toggles sound, `Esc` closes the inspector. On non-home pages, `←`/Backspace returns to the menu and `P` prints. Handlers ignore typing targets and suspend while the modal is open.
- **Button prompt bar.** Fixed console-style key hints along the bottom on desktop; hidden on mobile, where the tab bar takes over.
- **Menu sound.** Synthesised WebAudio blips, no audio files. Off by default, toggled from the roster, remembered per visitor. Storage is wrapped so private mode and sandboxed previews fall back to memory instead of throwing.
- **Inventory inspector.** Modal full-size viewer with prev/next, focus trap, and iframe cleared on close so nothing keeps rendering behind the scenes.
- **Contact form.** Validates, then composes a `mailto:` for the visitor's own mail app. No server, nothing stored, and the copy says so. To move to a hosted form service later, POST the same payload inside `send()` and keep the validation above it.
- **Konami unlock.** Reveals the secret-level stub link on Home and stays unlocked for that visitor.
- **No-JS behaviour.** A `<noscript>` block unhides all panels so the content stays readable with scripting off, and the four curated art cards ship as static HTML.

## Portfolio Data Behavior

The four curated Sketchfab cards in `CONTENT_SOURCE.md` are the static fallback and approved baseline. The live sync is intentional:

- when Art is opened, it attempts to fetch the account's current Sketchfab models;
- successful results replace the visible grid and can be sorted by likes, views, publication date, or name, filtered to Featured, and searched by name/description;
- the default list includes synced uploads, while Featured filters to the four approved model IDs;
- when the API is unavailable, the hand-written cards remain available and the status line says the sync failed rather than pretending otherwise;
- embeds use the shared dark, no-watermark query string documented in `CONTENT_SOURCE.md`;
- lazy loading stays enabled so all models do not load at once; Sketchfab thumbnails act as poster frames until a viewer starts;
- API pagination is bounded (10 pages / 60 models) and requests time out at 10s so the art panel cannot wait indefinitely;
- each model retains a direct Sketchfab link if its embedded viewer fails.

Do not remove this live sync or replace it with a different content source without updating this section and `CONTENT_SOURCE.md`.

## Change Checklist

Before finishing a change:

1. Read the relevant sections of both source files.
2. Keep factual content aligned with `CONTENT_SOURCE.md` (and its `data.js` mirror).
3. Keep implementation aligned with this guide.
4. Check responsive behavior for the affected layout.
5. Confirm existing links, IDs, and required fallback behavior remain intact.
6. Update this guide when the change is a major structural or directional shift.
7. Run `node test/smoke.js` — the jsdom suite covers routing, keyboard, sync and offline fallback, sorting, search, the inspector, form validation, and the easter egg.
