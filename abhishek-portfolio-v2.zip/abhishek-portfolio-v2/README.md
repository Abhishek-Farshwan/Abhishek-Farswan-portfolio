# Abhishek Farshwan — portfolio

A 3D artist's portfolio built as a console/JRPG menu. Plain HTML, CSS and JS.
No framework, no build step, no dependencies to install.

## Run it

Double-click `index.html`. That's it — everything works from `file://`,
including the Sketchfab sync.

If you'd rather serve it (recommended once you're testing on your phone):

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Before you publish

1. **Drop `user.png` at the site root.** It's the favicon and the roster
   avatar. Without it the avatar falls back to an "AF" pixel block — nothing
   breaks, it just looks less like you.
2. Open `sitemap.xml` and `robots.txt` and replace `https://example.com` with
   your real domain.
3. Check the résumé page prints the way you want: open `resume.html`, hit
   `P` (or the PRINT / SAVE PDF button), and choose "Save as PDF".

## Deploying

Any static host works. No build command, publish directory is the project root.

- **GitHub Pages** — push the repo, Settings → Pages → deploy from branch.
  `404.html` is picked up automatically.
- **Netlify / Vercel / Cloudflare Pages** — drag the folder in, or connect the
  repo. Leave the build command empty.

## Editing

**Facts** (links, résumé, model IDs, bio) live in `CONTENT_SOURCE.md` first,
then `assets/js/data.js`. Static HTML in `index.html` and `resume.html`
carries the same copy for no-JS readers — if you change a fact, grep for it in
both.

**Design values** (colour, type, spacing, motion) live in
`assets/css/tokens.css` and nowhere else. Change a token, the whole site
follows.

**Structure and direction** live in `PROJECT_GUIDE.md`. **Creative intent and
thesis** — the *why*, not the *what* — live in `DESIGN_DIRECTION.md`. **A
dated log of decisions already made**, including things proposed and
rejected, lives in `AGENT_CONTEXT.md`. Read all three before any structural
or design change; they're also what an AI assistant should read before
editing this repo, so a new session doesn't relitigate a closed
conversation.

### Common edits

| You want to… | Edit |
|---|---|
| Add or change a social link | `assets/js/data.js` → `links`, and the contact panel in `index.html` |
| Change the featured four models | `assets/js/data.js` → `sketchfab.featuredIds` and `featured` |
| Change a colour or the border weight | `assets/css/tokens.css` |
| Add a menu entry | `assets/js/data.js` → `nav`, then add a matching `<section class="panel" id="panel-…">` in `index.html` |
| Change résumé content | `resume.html` and `assets/js/data.js` → `resume` |
| Send the contact form to a real backend | `assets/js/contact.js` → replace the `mailto:` in `compose()` with a POST, and update the form note copy |

## Keyboard

| Key | Does |
|---|---|
| `↑` `↓` `←` `→` | move the menu cursor |
| `Enter` | select |
| `1`–`5` | jump straight to a panel |
| `R` | open the résumé |
| `M` | toggle menu sound |
| `Esc` | close the model inspector |
| `←` / `Backspace` | back to the menu (résumé, 404, secret level) |
| `P` | print (résumé) |

There's one more sequence. It's older than you are.

## Art grid

Opening **Art** syncs live with the Sketchfab account, so new uploads show up
without touching the code. Requests are bounded (10 pages / 60 models) and
time out after 10s. If the API is unreachable, the four curated models stay
and the status line says the sync failed. Viewers only start loading as they
reach the screen, and every model keeps a direct Sketchfab link in case its
embed fails.

## Tests

`test/smoke.js` loads the real pages in jsdom, runs the real scripts, mocks the
Sketchfab API, and asserts the interactions — routing, keyboard, sync and
offline fallback, sorting, search, empty state, the inspector, form validation
and the easter egg.

```bash
npm install jsdom   # only dependency, only for tests
node test/smoke.js
```

Run it after any change to `assets/js/`.

## Browser support

Modern evergreen browsers. Graceful degradation is built in: no
`IntersectionObserver` loads every viewer directly, no `matchMedia` falls back
to desktop assumptions, no `localStorage` falls back to memory, no
`AudioContext` silently skips sound, and no JavaScript at all still renders
every panel and the curated art set.
